﻿namespace Archivos
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gparchivo = new System.Windows.Forms.GroupBox();
            this.btnGuardarTxt = new System.Windows.Forms.Button();
            this.btnGuardarCsv = new System.Windows.Forms.Button();
            this.btnMas = new System.Windows.Forms.Button();
            this.btnGuardarXml = new System.Windows.Forms.Button();
            this.btnXml = new System.Windows.Forms.Button();
            this.btnTxt = new System.Windows.Forms.Button();
            this.btnRtf = new System.Windows.Forms.Button();
            this.lblNombre = new System.Windows.Forms.Label();
            this.btnDelFila = new System.Windows.Forms.Button();
            this.btnColumnas = new System.Windows.Forms.Button();
            this.dtGCSV = new System.Windows.Forms.DataGridView();
            this.cmdCSV = new System.Windows.Forms.Button();
            this.gparchivo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtGCSV)).BeginInit();
            this.SuspendLayout();
            // 
            // gparchivo
            // 
            this.gparchivo.Controls.Add(this.btnGuardarTxt);
            this.gparchivo.Controls.Add(this.btnGuardarCsv);
            this.gparchivo.Controls.Add(this.btnMas);
            this.gparchivo.Controls.Add(this.btnGuardarXml);
            this.gparchivo.Controls.Add(this.btnXml);
            this.gparchivo.Controls.Add(this.btnTxt);
            this.gparchivo.Controls.Add(this.btnRtf);
            this.gparchivo.Controls.Add(this.lblNombre);
            this.gparchivo.Controls.Add(this.btnDelFila);
            this.gparchivo.Controls.Add(this.btnColumnas);
            this.gparchivo.Controls.Add(this.dtGCSV);
            this.gparchivo.Controls.Add(this.cmdCSV);
            this.gparchivo.Location = new System.Drawing.Point(11, 11);
            this.gparchivo.Margin = new System.Windows.Forms.Padding(2);
            this.gparchivo.Name = "gparchivo";
            this.gparchivo.Padding = new System.Windows.Forms.Padding(2);
            this.gparchivo.Size = new System.Drawing.Size(595, 348);
            this.gparchivo.TabIndex = 2;
            this.gparchivo.TabStop = false;
            this.gparchivo.Text = "Cargar Archivo";
            this.gparchivo.Enter += new System.EventHandler(this.gparchivo_Enter);
            // 
            // btnGuardarTxt
            // 
            this.btnGuardarTxt.Location = new System.Drawing.Point(446, 46);
            this.btnGuardarTxt.Name = "btnGuardarTxt";
            this.btnGuardarTxt.Size = new System.Drawing.Size(83, 22);
            this.btnGuardarTxt.TabIndex = 17;
            this.btnGuardarTxt.Text = "Guardar TXT";
            this.btnGuardarTxt.UseVisualStyleBackColor = true;
            this.btnGuardarTxt.Click += new System.EventHandler(this.btnGuardarTxt_Click);
            // 
            // btnGuardarCsv
            // 
            this.btnGuardarCsv.Location = new System.Drawing.Point(447, 74);
            this.btnGuardarCsv.Name = "btnGuardarCsv";
            this.btnGuardarCsv.Size = new System.Drawing.Size(83, 22);
            this.btnGuardarCsv.TabIndex = 16;
            this.btnGuardarCsv.Text = "Guardar CSV";
            this.btnGuardarCsv.UseVisualStyleBackColor = true;
            this.btnGuardarCsv.Click += new System.EventHandler(this.btnGuardarCsv_Click);
            // 
            // btnMas
            // 
            this.btnMas.Location = new System.Drawing.Point(336, 270);
            this.btnMas.Name = "btnMas";
            this.btnMas.Size = new System.Drawing.Size(85, 19);
            this.btnMas.TabIndex = 15;
            this.btnMas.Text = "Mas filas";
            this.btnMas.UseVisualStyleBackColor = true;
            this.btnMas.Click += new System.EventHandler(this.btnMas_Click);
            // 
            // btnGuardarXml
            // 
            this.btnGuardarXml.Location = new System.Drawing.Point(446, 18);
            this.btnGuardarXml.Name = "btnGuardarXml";
            this.btnGuardarXml.Size = new System.Drawing.Size(83, 22);
            this.btnGuardarXml.TabIndex = 14;
            this.btnGuardarXml.Text = "Guardar XML";
            this.btnGuardarXml.UseVisualStyleBackColor = true;
            this.btnGuardarXml.Click += new System.EventHandler(this.btnLeer_Click);
            // 
            // btnXml
            // 
            this.btnXml.Location = new System.Drawing.Point(123, 289);
            this.btnXml.Margin = new System.Windows.Forms.Padding(2);
            this.btnXml.Name = "btnXml";
            this.btnXml.Size = new System.Drawing.Size(49, 19);
            this.btnXml.TabIndex = 13;
            this.btnXml.Text = "XML";
            this.btnXml.UseVisualStyleBackColor = true;
            this.btnXml.Click += new System.EventHandler(this.btnXml_Click);
            // 
            // btnTxt
            // 
            this.btnTxt.Location = new System.Drawing.Point(75, 289);
            this.btnTxt.Margin = new System.Windows.Forms.Padding(2);
            this.btnTxt.Name = "btnTxt";
            this.btnTxt.Size = new System.Drawing.Size(44, 19);
            this.btnTxt.TabIndex = 12;
            this.btnTxt.Text = "TXT";
            this.btnTxt.UseVisualStyleBackColor = true;
            this.btnTxt.Click += new System.EventHandler(this.btnTxt_Click);
            // 
            // btnRtf
            // 
            this.btnRtf.Location = new System.Drawing.Point(176, 289);
            this.btnRtf.Margin = new System.Windows.Forms.Padding(2);
            this.btnRtf.Name = "btnRtf";
            this.btnRtf.Size = new System.Drawing.Size(43, 19);
            this.btnRtf.TabIndex = 11;
            this.btnRtf.Text = "RTF";
            this.btnRtf.UseVisualStyleBackColor = true;
            this.btnRtf.Click += new System.EventHandler(this.btnRtf_Click);
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Location = new System.Drawing.Point(444, 141);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(0, 13);
            this.lblNombre.TabIndex = 10;
            // 
            // btnDelFila
            // 
            this.btnDelFila.Location = new System.Drawing.Point(245, 270);
            this.btnDelFila.Name = "btnDelFila";
            this.btnDelFila.Size = new System.Drawing.Size(85, 19);
            this.btnDelFila.TabIndex = 5;
            this.btnDelFila.Text = "Delete fila";
            this.btnDelFila.UseVisualStyleBackColor = true;
            this.btnDelFila.Click += new System.EventHandler(this.btnDelFila_Click);
            // 
            // btnColumnas
            // 
            this.btnColumnas.Location = new System.Drawing.Point(245, 295);
            this.btnColumnas.Name = "btnColumnas";
            this.btnColumnas.Size = new System.Drawing.Size(85, 19);
            this.btnColumnas.TabIndex = 4;
            this.btnColumnas.Text = "Mas columnas";
            this.btnColumnas.UseVisualStyleBackColor = true;
            this.btnColumnas.Click += new System.EventHandler(this.btnColumnas_Click);
            // 
            // dtGCSV
            // 
            this.dtGCSV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtGCSV.Location = new System.Drawing.Point(15, 18);
            this.dtGCSV.Margin = new System.Windows.Forms.Padding(2);
            this.dtGCSV.Name = "dtGCSV";
            this.dtGCSV.RowTemplate.Height = 24;
            this.dtGCSV.Size = new System.Drawing.Size(408, 247);
            this.dtGCSV.TabIndex = 3;
            // 
            // cmdCSV
            // 
            this.cmdCSV.Location = new System.Drawing.Point(21, 289);
            this.cmdCSV.Margin = new System.Windows.Forms.Padding(2);
            this.cmdCSV.Name = "cmdCSV";
            this.cmdCSV.Size = new System.Drawing.Size(50, 19);
            this.cmdCSV.TabIndex = 2;
            this.cmdCSV.Text = "CSV";
            this.cmdCSV.UseVisualStyleBackColor = true;
            this.cmdCSV.Click += new System.EventHandler(this.cmdCSV_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(663, 395);
            this.Controls.Add(this.gparchivo);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gparchivo.ResumeLayout(false);
            this.gparchivo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtGCSV)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox gparchivo;
        private System.Windows.Forms.Button cmdCSV;
        private System.Windows.Forms.DataGridView dtGCSV;
        private System.Windows.Forms.Button btnColumnas;
        private System.Windows.Forms.Button btnDelFila;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Button btnXml;
        private System.Windows.Forms.Button btnTxt;
        private System.Windows.Forms.Button btnRtf;
        private System.Windows.Forms.Button btnGuardarXml;
        private System.Windows.Forms.Button btnMas;
        private System.Windows.Forms.Button btnGuardarTxt;
        private System.Windows.Forms.Button btnGuardarCsv;
    }
}

