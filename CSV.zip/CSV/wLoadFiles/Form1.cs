﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Xml.Serialization;


namespace Archivos
{
    public partial class Form1 : Form
    {
        List<Person> p1 = new List<Person>();

        public Form1()
        {
            InitializeComponent();

        }




        private void gparchivo_Enter(object sender, EventArgs e)
        {

        }

        private void cmdCSV_Click(object sender, EventArgs e)
        {
            char delimitador = ';';

            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "Archivos CSV (*.csv)|*.csv";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string[] lines = File.ReadAllLines(openFileDialog1.FileName);
                   


                    string[] headers = lines[0].Split(delimitador);


                    dtGCSV.Columns.Clear();
                    foreach (string header in headers)
                    {
                        DataGridViewTextBoxColumn column = new DataGridViewTextBoxColumn();
                        column.HeaderText = header;
                        dtGCSV.Columns.Add(column);
                    }

                    
                    for (int i = 1; i < lines.Length; i++)
                    {
                        string[] values = lines[i].Split(delimitador);
                        dtGCSV.Rows.Add(values);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al leer el archivo CSV: " + ex.Message);
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnColumnas_Click(object sender, EventArgs e)
        {
            
            DataGridViewTextBoxColumn nuevaColumna = new DataGridViewTextBoxColumn();
            nuevaColumna.HeaderText = "Columna" + (dtGCSV.Columns.Count + 1);
            nuevaColumna.Width = 200;
            nuevaColumna.ReadOnly = false;
            dtGCSV.Columns.Add(nuevaColumna);
        }

        private void btnDelFila_Click(object sender, EventArgs e)
        {
            
            if (dtGCSV.SelectedRows.Count > 0)
            {
                dtGCSV.Rows.RemoveAt(dtGCSV.SelectedRows[0].Index);
            }
            else
            {
                MessageBox.Show("Debe seleccionar una fila para eliminarla.");
            }
        }

        private void btnLeer_Click(object sender, EventArgs e)
        {
            XmlSerializer serial = new XmlSerializer(typeof(List<Person>));
            using (System.IO.FileStream fs = new FileStream(Environment.CurrentDirectory + "\\personas.xml", FileMode.Open, FileAccess.Read))
            {
                p1 = serial.Deserialize(fs) as List<Person>;
            }

            // Mostrar los datos en el DataGridView
            dtGCSV.DataSource = null;
            dtGCSV.DataSource = p1;
        }

        private void btnTxt_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "Archivos (*.txt)|*.txt";


            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string[] lines = File.ReadAllLines(openFileDialog1.FileName);

                    
                    string[] firstLine = lines[0].Split(';');
                    int columnCount = firstLine.Length;

                    
                    dtGCSV.Rows.Clear();
                    dtGCSV.Columns.Clear();

                    
                    for (int i = 0; i < columnCount; i++)
                    {
                        DataGridViewTextBoxColumn column = new DataGridViewTextBoxColumn();
                        column.HeaderText = "Columna " + (i + 1);
                        dtGCSV.Columns.Add(column);
                    }

                    
                    foreach (string line in lines)
                    {
                        string[] values = line.Split(';');
                        dtGCSV.Rows.Add(values);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al leer el archivo: " + ex.Message);
                }
            }
        }

        private void btnXml_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Archivos XML (*.xml)|*.xml";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    DataSet ds = new DataSet();
                    ds.ReadXml(openFileDialog.FileName);

                  
                    dtGCSV.DataSource = ds.Tables[0];
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar el archivo XML: " + ex.Message);
                }
            }
        }

        private void btnMas_Click(object sender, EventArgs e)
        {
            
            int indiceUltimaFila = dtGCSV.Rows.Add();

            
            dtGCSV.Rows[indiceUltimaFila].Cells[0].Value = "";
            dtGCSV.Rows[indiceUltimaFila].Cells[1].Value = "";
            
        }

        private void btnGuardarCsv_Click(object sender, EventArgs e)
        {
            using (StreamWriter sw = new StreamWriter("datos.csv"))
            {
                foreach (DataGridViewRow row in dtGCSV.Rows)
                {
                    string linea = string.Join(",", row.Cells.Cast<DataGridViewCell>().Select(c => c.Value));
                    sw.WriteLine(linea);
                }
            }
        }

        private void btnGuardarTxt_Click(object sender, EventArgs e)
        {
            using (StreamWriter sw = new StreamWriter("datos.txt"))
            {
                foreach (DataGridViewRow row in dtGCSV.Rows)
                {
                    string linea = string.Join("\t", row.Cells.Cast<DataGridViewCell>().Select(c => c.Value));
                    sw.WriteLine(linea);
                }
            }
        }

        private void btnRtf_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Error: el boton no funciona correctamente");
        }
    }
}


public class Person
{
    public int Id { get; set; }
    public string Nombre { get; set; }
}