﻿namespace Trabajo
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.PDF1 = new AxAcroPDFLib.AxAcroPDF();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.btnPdf = new System.Windows.Forms.Button();
            this.btnReproductor = new System.Windows.Forms.Button();
            this.btnInternet = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.MediaPlayer = new AxWMPLib.AxWindowsMediaPlayer();
            ((System.ComponentModel.ISupportInitialize)(this.PDF1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MediaPlayer)).BeginInit();
            this.SuspendLayout();
            // 
            // PDF1
            // 
            this.PDF1.Enabled = true;
            this.PDF1.Location = new System.Drawing.Point(51, 156);
            this.PDF1.Name = "PDF1";
            this.PDF1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("PDF1.OcxState")));
            this.PDF1.Size = new System.Drawing.Size(268, 264);
            this.PDF1.TabIndex = 0;
            // 
            // webBrowser1
            // 
            this.webBrowser1.Location = new System.Drawing.Point(670, 120);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(750, 286);
            this.webBrowser1.TabIndex = 2;
            // 
            // btnPdf
            // 
            this.btnPdf.Location = new System.Drawing.Point(134, 42);
            this.btnPdf.Name = "btnPdf";
            this.btnPdf.Size = new System.Drawing.Size(116, 37);
            this.btnPdf.TabIndex = 3;
            this.btnPdf.Text = "Go";
            this.btnPdf.UseVisualStyleBackColor = true;
            this.btnPdf.Click += new System.EventHandler(this.btnPdf_Click);
            // 
            // btnReproductor
            // 
            this.btnReproductor.Location = new System.Drawing.Point(435, 42);
            this.btnReproductor.Name = "btnReproductor";
            this.btnReproductor.Size = new System.Drawing.Size(116, 37);
            this.btnReproductor.TabIndex = 4;
            this.btnReproductor.Text = "Go";
            this.btnReproductor.UseVisualStyleBackColor = true;
            this.btnReproductor.Click += new System.EventHandler(this.btnReproductor_Click);
            // 
            // btnInternet
            // 
            this.btnInternet.Location = new System.Drawing.Point(1018, 53);
            this.btnInternet.Name = "btnInternet";
            this.btnInternet.Size = new System.Drawing.Size(116, 37);
            this.btnInternet.TabIndex = 5;
            this.btnInternet.Text = "Go";
            this.btnInternet.UseVisualStyleBackColor = true;
            this.btnInternet.Click += new System.EventHandler(this.btnInternet_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // MediaPlayer
            // 
            this.MediaPlayer.Enabled = true;
            this.MediaPlayer.Location = new System.Drawing.Point(370, 156);
            this.MediaPlayer.Name = "MediaPlayer";
            this.MediaPlayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("MediaPlayer.OcxState")));
            this.MediaPlayer.Size = new System.Drawing.Size(255, 52);
            this.MediaPlayer.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1453, 450);
            this.Controls.Add(this.btnInternet);
            this.Controls.Add(this.btnReproductor);
            this.Controls.Add(this.btnPdf);
            this.Controls.Add(this.webBrowser1);
            this.Controls.Add(this.MediaPlayer);
            this.Controls.Add(this.PDF1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.PDF1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MediaPlayer)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private AxAcroPDFLib.AxAcroPDF PDF1;
        private AxWMPLib.AxWindowsMediaPlayer MediaPlayer;
        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.Button btnPdf;
        private System.Windows.Forms.Button btnReproductor;
        private System.Windows.Forms.Button btnInternet;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}

