﻿using AxWMPLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trabajo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            MediaPlayer.Ctlcontrols.stop();
            MediaPlayer.Enabled = true;
            PDF1.Enabled = true;
        }

        private void btnPdf_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                PDF1.src = openFileDialog.FileName;
                
            }
        }

        private void btnReproductor_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                MediaPlayer.URL = openFileDialog.FileName;
                MediaPlayer.Ctlcontrols.play();
            }
        }

        private void btnInternet_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate(btnInternet.Text);
        }
    }
}
