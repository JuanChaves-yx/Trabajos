﻿using AxWMPLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TrabajoWF
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            MediaPlayer.Ctlcontrols.stop();
            MediaPlayer.Enabled = true;
        }

        private void btnUno_Click(object sender, EventArgs e)
        {

        }

        private void btnDos_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                MediaPlayer.URL = openFileDialog.FileName;
                MediaPlayer.Ctlcontrols.play();
            }
        }
    }
}
